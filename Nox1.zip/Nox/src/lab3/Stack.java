package lab3;

import java.util.ArrayList;

import se.liu.noaan869.lab1.Person;

public class Stack extends ListManager {
	
	public Stack() {
		super();
		this.elements = new ArrayList<Person>();
	}

	public void push(Person e) {
		add(e);
	}
	
	public Person pop() {
		Person first = elements.get(0); 
		remove(0); 
		return first;
	}
	
	
}
