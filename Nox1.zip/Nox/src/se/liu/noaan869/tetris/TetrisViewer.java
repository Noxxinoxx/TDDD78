package se.liu.noaan869.tetris;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class TetrisViewer {
	
	private JFrame frame;
	private Board board;
	private JTextArea displayBoard;
	
	public TetrisViewer(Board board) {
		//Constructor for TetrisViewer
		super(); 
		this.setBoard(board);
		
	}
	
	public void show(String title) {
		//show function that create a JFrame window and puts our board in a JTextArea for displaying.
		//BoardToTextConveter init.
		BoardToTextConverter b = new BoardToTextConverter();
		//get Stringifiyed board.
		String StringBoard = b.convertToText(board);
		
		//create Text area.
		JTextArea area = new JTextArea(StringBoard); 
		//update private varibale for play field.
		this.setDisplayBoard(area);
		 
		//init JFrame
		JFrame f = new JFrame();  
        
		//set all the options for JFrame and TextArea
        f.setLayout(new BorderLayout());
        f.add(area, BorderLayout.CENTER);  
        area.setFont(new Font("Monospaced", Font.PLAIN, 20));
        f.pack();
        f.setVisible(true);  
        
		
	}

	
	
	//gets and setters for varibles.
	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	public Board getBoard() {
		return board;
	}

	public void setBoard(Board board) {
		this.board = board;
	}

	public JTextArea getDisplayBoard() {
		return displayBoard;
	}

	public void setDisplayBoard(JTextArea displayBoard) {
		this.displayBoard = displayBoard;
	}
	
	
	
	
	
}
