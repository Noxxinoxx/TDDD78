package se.liu.noaan869.tetris;

public class TestBoard {
	public static void main(String[] args) {
		//Test class also used to run the program at this point. implement main game loop class soon.
		Board b = new Board(10, 15); 
		TeroMaker t = new TeroMaker();
		Poly p = t.getPoly(4);
		Vy v = new Vy(b.getWidth(), b.getHeight(), b.getSquares());
		b.setSquares(v.drawEmptyBoard());
		b.AddPoly(1, 1, b, p);
		TetrisViewer tt = new TetrisViewer(b); 
		tt.show("Tetris");

	}
	
}
