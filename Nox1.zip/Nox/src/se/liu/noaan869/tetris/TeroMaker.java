package se.liu.noaan869.tetris;

public class TeroMaker {

	    public int getNumberOfTypes() {
	        return SquareType.values().length;
	    }
	    
	    public Poly getPoly(int n) {
	    	//checks so we are not out of bounds for enum class.
	        if(getNumberOfTypes() > 8) {
	            throw new IllegalArgumentException("Invalid index: " + n);
	        }
	        //switch class to get intended n block from enum.
	        Poly polyblock = new Poly(new SquareType[0][0]);
	        switch (SquareType.values()[n]) {
	            case I:
	                polyblock = new Poly(blockI(new SquareType[4][4]));
	                break;
	            case J:
	                polyblock = new Poly(blockJ(new SquareType[3][3]));
	                break;
	            case O:
	                polyblock = new Poly(blockO(new SquareType[3][4]));
	                break;
	            case S:
	                polyblock = new Poly(blockS(new SquareType[3][3]));
	                break;
	            case T:
	                polyblock = new Poly(blockT(new SquareType[3][3]));
	                break;
	            case Z:
	                polyblock = new Poly(blockZ(new SquareType[3][3]));
	                break;
	            case L: 
	            	polyblock = new Poly(blockL(new SquareType[3][3]));
	                break;


	        }
	        return polyblock;
	    }
	    
	    
	   //maker function that creates out tetrominos.

	    public SquareType[][] blockI(SquareType[][] list) {
	        for (int y = 0; y < 4; y++) {
	            for (int x = 0; x < 4; x++) {
	                if (y == 1) {
	                    list[y][x] = SquareType.I;
	                } else {
	                    list[y][x] = SquareType.EMPTY;
	                }
	            }
	        }

	        return list;
	    }

	    public SquareType[][] blockJ(SquareType[][] list) {
	        for (int y = 0; y < 3; y++) {
	            for (int x = 0; x < 3; x++) {
	                if ((y == 2 && x == 0) || (x == 1) ) {
	                    list[y][x] = SquareType.J;
	                } else {
	                    list[y][x] = SquareType.EMPTY;
	                }
	            }
	        }

	        return list;
	    }

	    public SquareType[][] blockL(SquareType[][] list) {
	        for (int y = 0; y < 3; y++) {
	            for (int x = 0; x < 3; x++) {
	                if ((y == 2 && x == 2)||(x == 1)) {
	                    list[y][x] = SquareType.L;
	                } else {
	                    list[y][x] = SquareType.EMPTY;
	                }
	            }
	        }
	        return list;

	    }

	    public SquareType[][] blockO(SquareType[][] list) {
	        for (int y = 0; y < 3; y++) {
	            for (int x = 0; x < 4; x++) {
	                if ((y == 0 && (x == 1 || x == 2)) || (y == 1 && (x == 1 || x == 2))) {
	                    list[y][x] = SquareType.O;
	                } else {
	                    list[y][x] = SquareType.EMPTY;
	                }
	            }
	        }
	        return list;
	    }
	    public SquareType[][] blockS(SquareType[][] list) {
	        for (int y = 0; y < 3; y++) {
	            for (int x = 0; x < 3; x++) {
	                if ((y == 0 && (x == 1 || x == 2)) || (y == 1 && (x == 0 || x == 1))) {
	                    list[y][x] = SquareType.S;
	                } else {
	                    list[y][x] = SquareType.EMPTY;
	                }
	            }
	        }
	        return list;
	    }
	    public SquareType[][] blockT(SquareType[][] list) {
	        for (int y =  0; y < 3; y++) {
	            for (int x = 0; x < 3; x++) {
	                if ((y == 0 && x == 1) || (y == 1)) {
	                    list[y][x] = SquareType.T;
	                } else {
	                    list[y][x] = SquareType.EMPTY;
	                }
	            }
	        }
	        return list;
	    }
	    
	    public SquareType[][] blockZ(SquareType[][] list) {
	        for (int y = 0; y < 3; y++) {
	            for (int x = 0; x < 3; x++) {
	                if ((y == 0 && (x == 0 || x == 1)) || (y == 1 && (x == 1 || x == 2)))  {
	                    list[y][x] = SquareType.Z;
	                }
	                else {
	                    list[y][x] = SquareType.EMPTY;
	                }
	      
	            }
	        }
	        return list;
	    }

}