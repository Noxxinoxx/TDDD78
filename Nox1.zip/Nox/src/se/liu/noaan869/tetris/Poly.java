package se.liu.noaan869.tetris;

public class Poly {

	private SquareType[][] block; 
	
	public Poly(SquareType[][] block) {
		this.block = block;
		
	}

	public SquareType[][] getBlock() {
		return block;
	}

	public void setBlock(SquareType[][] block) {
		this.block = block;
	}
	
	
	//get width and height for tetromino.
	public int getWidth() {
		return this.getBlock()[0].length;
	}
	public int getHeight() {
		return this.getBlock().length;
	}
	
}
