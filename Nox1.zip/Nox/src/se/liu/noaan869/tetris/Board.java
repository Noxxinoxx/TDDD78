package se.liu.noaan869.tetris;


public class Board {
	
	private SquareType[][] squares;
	private int width; 
	private int height;
	
	private Vy v;
	
	private Poly falling;
	private int fallingx; 
	private int fallingy;
	
	public Board(int width, int height) {
		super();
		this.setSquares(new SquareType[height][width]);
		this.setWidth(width);
		this.setHeight(height);
		this.v = new Vy(width, height, squares);
		this.setSquares(this.v.drawEmptyBoard());
	}
	
	
	
	public void AddPoly(int x,int y, Board board, Poly poly) {
		//plays the tetromino on the board.
		this.setFallingx(x);
		this.setFallingy(y);
		this.setFalling(poly);
		
		int x2 = x + poly.getWidth();
		int y2 = y + poly.getHeight();
		
		if(x2 < board.width && y2 < board.height) {
			for(int py = 0; py < y2 - y; py++) {
				for(int px = 0; px < x2 - x; px++) {
					board.setType(px + x ,py + y, poly.getBlock()[py][px]);
				}
			}
		}
		
		
	}
	public Vy getVy() {
		return v;
	}
	
	public SquareType getType(int x, int y) {
		return squares[y][x];
	}
	public SquareType setType(int x, int y, SquareType type) {
		return squares[y][x] = type;
	}

	public SquareType[][] getSquares() {
		return squares;
	}

	public void setSquares(SquareType[][] squares) {
		this.squares = squares;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height; 
	}



	public Poly getFalling() {
		return falling;
	}


	public void setFalling(Poly falling) {
		this.falling = falling;
	}
	
	

	public int getFallingx() {
		return fallingx;
	}


	public void setFallingx(int fallingx) {
		this.fallingx = fallingx;
	}


	public int getFallingy() {
		return fallingy;
	}


	public void setFallingy(int fallingy) {
		this.fallingy = fallingy;
	}
	
	
	
}
