package lab3;

import java.util.ArrayList;

import se.liu.noaan869.lab1.Person;

public class Queue extends ListManager {
	
	public Queue() {
		super();
		this.elements = new ArrayList<Person>();
	}
	
	public void enqueue(Person e) {
		add(e);
	}
	
	public Person dequeue() {
		Person first = elements.get(0); 
		remove(0); 
		return first;
	}
	
	
}
