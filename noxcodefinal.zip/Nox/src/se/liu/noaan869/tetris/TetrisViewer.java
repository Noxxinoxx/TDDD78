package se.liu.noaan869.tetris;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.Timer;

public class TetrisViewer {
	
	private JFrame frame;
	private Board board;
	private TetrisComponent comp;
	private GUI imageicon;
	private int speed = 500;
	private int bsize = 20;
	
	public TetrisViewer(Board board) {
		frame = new JFrame();
        //make board
        this.board = board;
        comp = new TetrisComponent(board);
        imageicon = new GUI();
        input();
        board.addBoardListener(comp);
        GameTimer(board);
		
		
	}
	
	 private void GameTimer(Board board) {
		 
        
        //cat picture
        frame.setLayout(new GridLayout(1,1));
        frame.add(imageicon);
        frame.setSize(700, 700);
        frame.setVisible(true);
        

        final JMenuBar bar = new JMenuBar();
        final JButton end = new JButton("Avsluta");
        final JButton Paus = new JButton("Pause");
        
        final JLabel Score = new JLabel();

        end.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                if(shuldQuit()){
                    System.exit(0);
                }
            }

        });
        Paus.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                board.setPausedGame(true);
                boolean value = PauseGame();
                if(value == true) {
                	board.setPausedGame(false);
                }
            }

        });
        bar.add(end);
        bar.add(Paus);
        
        bar.add(Score);
        frame.setJMenuBar(bar);
        
        frame.setVisible(true);
        
        final Action doOneStep = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
            	//remove cat image after timer init.
            	frame.remove(imageicon);
            	//add ttetris play ground.
            	Score.setText("Score: " + board.getScore());
            	frame.add(comp, BorderLayout.CENTER);
            	frame.setSize(getPreferredSize());
            	
                board.tick(frame);
            }
        };
        
        //lab 5 change tick speed will make the tetrominos move faster.
        final Timer clockTimer = new Timer(speed, doOneStep);
        clockTimer.setCoalesce(true);
        clockTimer.setInitialDelay(5000);
        clockTimer.start();
        
        final Action speedAction = new AbstractAction() {
        	public void actionPerformed(ActionEvent e) {
        		System.out.println("speed: " + speed);
        		speed =  (int) (speed / 1.2f);
        		if(speed < 50) {
        			speed = 50;
        		}
            	clockTimer.setDelay(speed);
            }
        };
        
        
        final Timer SpeedTimer = new Timer(60000, speedAction);
        
        SpeedTimer.setCoalesce(true);
        SpeedTimer.setInitialDelay(5000);
        SpeedTimer.start();
        
	 }
	
	 public Dimension getPreferredSize(){
	        int dX = ((board.getWidth()-3)*bsize)-4;
	        int dY = ((board.getHeight()-1)*bsize)+4;
	        return new Dimension(dX ,dY);


	 }
	 
	 
	 
	 //keyboard actions used to call board function. That makes the board the repsoneble one for moveing and rotating of the Tetromino.
	 private class rotateA extends AbstractAction {
	        public void actionPerformed(ActionEvent e) {
	            board.rotate();

        }
    }
	 private class leftA extends AbstractAction {
        public void actionPerformed(ActionEvent e) {
            board.moveLeft();

        }
    }

    private class rightA extends AbstractAction {
        public void actionPerformed(ActionEvent e) {
            board.moveRight();

        }
    }
    private class downA extends AbstractAction {
        public void actionPerformed(ActionEvent e) {

            board.moveDown();

        }
    }

 
	//keyboard input listens for keyboard strokes and if a key is pressed the action above is called.
	private void input(){
        JComponent pane = frame.getRootPane();

        final InputMap in = pane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        
        final ActionMap act = pane.getActionMap();
        
        //keyboard listeners.
        in.put(KeyStroke.getKeyStroke("A"), "Left");
        act.put("Left",  new leftA());
        
        in.put(KeyStroke.getKeyStroke("S"), "Down");
        act.put("Down",  new downA());
        
        in.put(KeyStroke.getKeyStroke("D"), "Right");
        act.put("Right",  new rightA());

        in.put(KeyStroke.getKeyStroke("W"), "Rotate");
        act.put("Rotate",  new rotateA());

	     	
	}
	 
	public JFrame getFrame() {
		return frame;
	}
	
	public static boolean PauseGame() {
		if (askUserPasued("Game is Paused. UnPause?")){
            return true;
        }
		 return false;
	}
	
	public static boolean showErrorMessage(String error) {
		 if (askUser(error + " Try again?")){
             return true;
         }
		 return false;
        	
		
	}
	
	public static void showScoreBoard(String score) {
		JOptionPane.showMessageDialog(null, score);
	}
	
	public static void GameOver() {
		JOptionPane.showMessageDialog(null, "GameOver!");
	}
	
	public static String nameInput(){
	        return JOptionPane.showInputDialog("What your name?");
	}
	
	 
	 //ask user from old project / lab.
	public static boolean shuldQuit(){
         if (askUser("Quit?") && askUser("Relly?")){
             return true;
         }
         else return false;
	}
	private static boolean askUser(String question){
	        return JOptionPane.showConfirmDialog(null, question,
	                "", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
	}
	private static boolean askUserPasued(String question){
        return JOptionPane.showConfirmDialog(null, question,
                "", JOptionPane.DEFAULT_OPTION) == JOptionPane.YES_OPTION;
	}
}
