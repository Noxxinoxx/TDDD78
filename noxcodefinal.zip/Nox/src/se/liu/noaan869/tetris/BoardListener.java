package se.liu.noaan869.tetris;

public interface BoardListener {
	void boardChanged();
}
