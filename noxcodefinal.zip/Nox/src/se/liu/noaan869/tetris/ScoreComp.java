package se.liu.noaan869.tetris;

import java.util.Comparator;

public class ScoreComp implements Comparator<Highscore> {

    public int compare(Highscore o1, Highscore o2) {
        if(o1.getScore() > o2.getScore()) {
        	return -1;
        }else {
        	return 1;
        }
    }
}
