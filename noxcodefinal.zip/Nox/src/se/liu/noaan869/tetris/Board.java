package se.liu.noaan869.tetris;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JFrame;


public class Board {
	private boolean pauseGame = false;
	private SquareType[][] squares;
	private int width; 
	private int height;
	private boolean gameOver = false;
	private Vy v;
	
	private Poly falling = null;
	private int fallingx; 
	private int fallingy;
	private TetrisViewer Viewer;
	private List<BoardListener> listeners = new ArrayList<>();
	
	private int Score = 0;
	
	public Board(int width, int height) {
		this.width = width + 4; 
		this.height = height + 4;
		
		this.squares = new SquareType[this.height][this.width];
		EmptyGamePlan(); 
		notifyListeners();
	}
	private void EmptyGamePlan() {
		System.out.println(width);
        for (int y = 0; y < getHeight(); y++) {
            for (int x = 0; x < getWidth() ; x++) {
                if (y < 2 || (y >= (getHeight() - 2) && y <= getHeight()) || x < 2 ||(x >= (getWidth() - 2) && x <= getWidth())) {
                    this.squares[y][x] = SquareType.OUTSIDE;
                } else this.squares[y][x] = SquareType.EMPTY;
            }
        }
    }
	private void removeRow(){
		int rowsdel = 0;
		for(int y = 2; y < getHeight() - 2; y++) {
    	   boolean full = true;
    	   for(int x = 2; x < getWidth() - 2; x++) {
    		   if(getSquareAt(x,y) == SquareType.EMPTY) {
    			   full = false;
    			   break;
    		   }
    	   }
    	   if (full == true){
               for (int j = 2; j < getWidth() - 2; j++) {
            	   System.out.println("hej tv�");
            	   moveType(j,y, SquareType.EMPTY);
            	   
               }
               
              moveDownRows(y);
              rowsdel = rowsdel + 1;
           }
    	   
    	   
       }
		ScoreUpdater(rowsdel);
    }
	
	private void ScoreUpdater(int rows) {
		System.out.println(rows + "hej");
		//score system f�ljer ingen logisk process. 100-300-500-800? 
		if(rows == 1) {
			Score = Score + 100;
		}else if(rows == 2) {
			Score = Score + 300;
		}else if(rows == 3) {
			Score = Score + 500;
		}else if(rows == 4) {
			Score = Score + 800;
		}
	}
	
	private void moveDownRows(int rowYPos) {
		System.out.println(rowYPos + "pos y");
		System.out.println(getHeight() - 2);
		System.out.println(rowYPos + 2 + "y pos 2");
		
		for(int y = rowYPos; y > 2 ; y--) {
			//System.out.println("hej2");
     	   for(int x = 2; x < getWidth() - 2; x++) {
     		  //System.out.println("hej3");
     		   
     		  moveType(x,y, getSquareAt(x, (y - 1)));
     		
     	   }
        }
	}
	
    private void addFallingToBoard(){
        for (int i = 0; i < falling.getLength(); i++) {
            for (int j = 0; j < falling.getLength(); j++) {
                if(falling.getType(j,i) != SquareType.EMPTY){
                	setTypeAtPosOffset(j+getFallingx(), i+getFallingy(), falling.getType(j,i));
                }
            }

        }
       
    }
    public void rotate(){
        falling = falling.rotateRight();
    }

    private void setTypeAtPosOffset(int x, int y, SquareType type){
        this.squares[y + 1][x] = type;
    }

    private void moveType(int x, int y, SquareType type){
        this.squares[y][x] = type;
    }

    public void moveLeft() {
        setFallingx(getFallingx()-1);
        if(hasCollision()) {
            setFallingx(getFallingx() + 1);
        }
        else setFallingx(getFallingx());
    }

    public void moveRight() {
        setFallingx(getFallingx()+1);
        if(hasCollision()) {
            setFallingx(getFallingx() - 1);
        }else setFallingx(getFallingx());
    }

    public void moveDown(){
        if (!hasCollision()){
            setFallingy(getFallingy() + 1);
        }
    }

    private void makeFalling() {
    	removeRow();
        falling = new TeroMaker().getRandomPoly();
        fallingy = 1;
        fallingx = (int) getWidth() / 2;

    }
    
    
    
    public void StartGame() {
    	
    	Board b;
		b = new Board(15, 20);
     
		new TetrisViewer(b);
    }
    
    public void setPausedGame(boolean value) {
    	pauseGame = value;
    }
    
	public void tick(JFrame frame) {
        if (!gameOver) {
        	
        	
        	if(pauseGame != false) {
        		System.out.println("game is Paused!");
        	}else {

            	//make changes in here to paus the game.
            	//if u click on the paus button make a if statment that brings the game loop to a stop and insted adds a gui of some sort.
            	//System.out.println(getFallingy());
            	System.out.println(Score);
                if (getFalling() == null) {
                    makeFalling();
                    if (hasCollision()) {
                        gameOver = true;
                        //change to game over screen.
                        TetrisViewer.GameOver();
                        
                        //append name and score to hsList also shows the input name panel.
                        String name = TetrisViewer.nameInput();
                        Highscore highscore = new Highscore(name, getScore());
                    	HighscoreList currentHighscores = HighscoreList.getList();
                    	currentHighscores.add(highscore);
                    	
                    	
                    	//show the current highscore list
                    	TetrisViewer.showScoreBoard(currentHighscores.showList());
                		
                        
                        //dispose frame
                        frame.dispose();
                        
                        //make a task that 5 sec later restarts the game.
                        TimerTask Restart = new TimerTask() {
                            public void run() {
                        		//remove cat image after timer init.
                            	StartGame();    	
                        		
                            }
                        };
                        Timer timer = new Timer("Timer");
                        long delay = 5000L;
                        timer.schedule(Restart, delay);
                        

                    }
                } else if (!hasCollision()) {
                    setFallingy(getFallingy() + 1);

                } else {
                    setFallingy(getFallingy());
                    
                    addFallingToBoard();

                    falling = null;

                }

        	}
        	
            notifyListeners();
        }
    }
	
	 public boolean hasCollision() {
		//see if there is an active falling tetromino.
        if (falling != null) {
        	//loop over the poly that is falling 
            for (int i = 0; i < falling.getLength(); i++) {
                for (int j = 0; j < falling.getLength(); j++) {
                	//see if the poly is over not over an empty place.
                    if (falling.getType(j, i) != SquareType.EMPTY && this.getType(j + getFallingx(), i + getFallingy() +2) != SquareType.EMPTY) {
                        return true;
                    }
                }

            }
        }
        return false;
	}
	public SquareType getSquareAt(int x, int y) {

        if (falling != null && fallingx <= x && x < fallingx + falling.getLength() && y < fallingy + falling.getLength() && fallingy <= y) {
            notifyListeners();
            SquareType type =  falling.getBlock()[x - fallingx][y - fallingy];
            if (type != SquareType.EMPTY){
                return type;
            }
        }
        notifyListeners();
        return getType(x,y);

    }
	
	public int getScore() {
		return Score;
	}
	
	
	public SquareType[][] getSquares() {
		return squares;
	}

	public void setSquares(SquareType[][] squares) {
		this.squares = squares;
	}
	
	
	public List<BoardListener> getBoardListeners() {
	        return listeners;
    }

    public void addBoardListener(BoardListener bl) {
        listeners.add(bl);

    }

    public void removeBoardListener(BoardListener bl) {
        listeners.remove(bl);

    }
	
	
	private void notifyListeners() {
        if (listeners != null) {
            listeners.forEach(BoardListener::boardChanged);
        }
    }
	
	public Vy getVy() {
		return v;
	}
	
	public SquareType getType(int x, int y) {
		return squares[y][x];
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height; 
	}

	public Poly getFalling() {
		return falling;
	}

	public int getFallingx() {
		return fallingx;
	}


	public void setFallingx(int fallingx) {
		this.fallingx = fallingx;
	}


	public int getFallingy() {
		return fallingy;
	}


	public void setFallingy(int fallingy) {
		this.fallingy = fallingy;
	}
	
	
	
}
