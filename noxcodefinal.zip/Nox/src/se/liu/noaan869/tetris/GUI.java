package se.liu.noaan869.tetris;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.ImageIcon;
import javax.swing.JComponent;

public class GUI extends JComponent{
	
	final ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("images/cat.jpg"));

    public void paintComponent(final Graphics g) {
       final Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(	RenderingHints.KEY_ANTIALIASING,
			 RenderingHints.VALUE_ANTIALIAS_ON);

        icon.paintIcon(this, g, 50, 50);
    }
	
}
