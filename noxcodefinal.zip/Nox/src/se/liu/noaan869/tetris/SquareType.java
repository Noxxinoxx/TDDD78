package se.liu.noaan869.tetris;


public enum SquareType {
	EMPTY, I, O, T, S, Z, J, L, OUTSIDE;
}

