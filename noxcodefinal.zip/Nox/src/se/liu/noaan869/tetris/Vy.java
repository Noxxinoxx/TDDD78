package se.liu.noaan869.tetris;

import java.util.Random;

public class Vy {
	
	private int width; 
	private int height; 
	private SquareType[][] s;
	private final static Random r = new Random();
	
	
	//board creator class.
	public Vy(int width, int height, SquareType[][] s) {
		super(); 
		this.width = width; 
		this.height = height; 
		this.s = s;
	}
	
	
	
	public SquareType[][] RandomBoard() {
		for(int y = 0; y < height;y++) {
			for(int x = 0; x < width; x++) {
				int random = r.nextInt(8);
				SquareType l = SquareType.values()[random];
				s[x][y] = l;
				
			}
		}
		return s;
	}
	
	
	public SquareType[][] drawEmptyBoard() {
		for(int y = 0; y < height;y++) {
			
			for(int x = 0; x < width; x++) {
				//System.out.println(y + " " +x);
				s[y][x] = SquareType.EMPTY;
			}
		}
		return s;
	}
	
}
