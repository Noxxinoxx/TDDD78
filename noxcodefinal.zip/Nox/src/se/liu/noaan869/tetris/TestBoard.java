package se.liu.noaan869.tetris;

public class TestBoard {
	public static void main(String[] args) {
		//Test class also used to run the program at this point. implement main game loop class soon.
		//new HighscoreList();
		Board b;
        b = new Board(15, 20);
        
        new TetrisViewer(b);

	}
	
}
