package se.liu.noaan869.tetris;

public class BoardToTextConverter {
	//converts SquareType board to String board.
	public String convertToText(Board b) {
		String board = "";
		for(int y = 0; y < b.getHeight(); y++) {
			board = board + "\n";
			for(int x = 0; x < b.getWidth(); x++) {
				
				SquareType witchType = b.getType(x, y);
				switch (witchType) {
				case EMPTY: 
					board = board + "-,";
					break;
				case I: 
					board = board + "#,";
					break;
				case O: 
					board = board + "!,";
					break;
				case T: 
					board = board + "?,";
					break;
				case S: 
					board = board + "+,";
					break;
				case Z: 
					board = board + "�,";
					break;
				case J: 
					board = board + "%,";
					break;
				case L: 
					board = board + "&,";
					break;
				case OUTSIDE:
					board = board + "t,"; 
					break;
				}
			}
		}
		return board;
	}
}
